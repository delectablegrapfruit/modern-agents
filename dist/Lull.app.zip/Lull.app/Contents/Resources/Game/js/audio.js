// Lull — sound: synthesized effects in swappable packs (a Shop cosmetic) and Classic's music, all made on the fly with
// Web Audio, plus Classic's announcer, whose recorded clips are embedded (voice-data.js): nothing to download.
(function (root) {
  'use strict';
  const L = (root.Lull = root.Lull || {});

  const PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26, 28, 31];
  const note = (base, step) => base * Math.pow(2, (PENTA[Math.max(0, Math.min(PENTA.length - 1, step))]) / 12);
  const rand = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const hz = (m) => 440 * Math.pow(2, (m - 69) / 12); // MIDI note to Hz (A4 = 69)
  const AM = [0, 3, 5, 7, 10, 12, 15, 17, 19, 22, 24]; // A minor pentatonic, in semitones from A

  /**
   * A pack turns an event into voices:
   *   f frequency · to slide target · d duration · w wave · g gain · at delay · a attack
   *   n noise burst · q low-pass · hp high-pass · bp band-pass · fe [from, to] low-pass sweep over the note
   *   p partials [[multiple, level, decay share]] · dt detuned twin (cents) · vib vibrato (cents) · rv reverb send
   *   fm [ratio, index, decay share] a sine modulating the tone's pitch, its depth fading · pan stereo position
   * Packs may voice any event themselves; the rest fall back to Sound.common in the pack's wave, scale and room.
   */
  const PACKS = {
    // The default, in the music's world: glassy FM tones, water droplets and airy chord swells, all in A minor (and
    // its relative, C major) so they sit with Classic's music. Movement is barely there; clears bloom and fade.
    soft: {
      // Shared sounds (Sound.common) fall on the C major pentatonic from here: A minor's notes too.
      base: 523, wave: 'sine', decay: 0.9, reverb: 0.1, attack: 0.01,
      // A glass tone: a sine with a brief inharmonic FM shimmer on its attack.
      glass: (m, at, g, d, o) => Object.assign({ f: hz(m), at, g, d, a: 0.005, fm: [3.5, 0.45, 0.12], rv: 0.14 }, o),
      // A soft electric-piano tone: FM at a ratio of one, warm and round, fading bright to plain.
      keys: (m, at, g, d, o) => Object.assign({ f: hz(m), at, g, d, a: 0.01, fm: [1, 0.9, 0.25], dt: 5, rv: 0.16 }, o),
      // A droplet: a short sine that slides up as it fades.
      drop: (m, at, g, d, o) => Object.assign({ f: hz(m), to: hz(m) * 1.33, at, g, d, a: 0.003, rv: 0.08 }, o),
      // Air: a slow-swelling detuned pair, for pads under chords.
      air: (m, at, g, d, o) => Object.assign({ f: hz(m), at, g, d, a: 0.14, dt: 7, rv: 0.2 }, o),
      move() { return [this.drop(72, 0, 0.028, 0.07)]; },
      rotate() { return [this.glass(76, 0, 0.045, 0.2, { fm: [2, 0.35, 0.1], rv: 0.12 })]; },
      lower() { return [this.drop(64, 0, 0.036, 0.08, { to: hz(67) })]; },
      lock() { return [{ f: 110, to: 98, d: 0.38, g: 0.17, a: 0.008 }, this.keys(57, 0, 0.06, 0.4, { dt: 0, rv: 0.1 }), { n: 1, d: 0.08, g: 0.018, q: 700 }]; },
      hold() { return [this.air(69, 0, 0.032, 0.45, { to: hz(72), a: 0.06 }), this.glass(76, 0.05, 0.016, 0.4, { pan: 0.3 })]; },
      blocked() { return [{ f: hz(50), d: 0.12, g: 0.03, a: 0.006, q: 500 }]; },
      // A line: an Am chord (A C E, then G, then B for Am9) blooming up, over a breath of air.
      clear(s, n) {
        n = Math.min(n || 1, 3);
        const tones = [69, 72, 76, 79, 83].slice(0, 2 + n);
        return [this.air(57, 0, 0.045, 1.4)].concat(tones.map((m, i) => this.keys(m, i * 0.045, 0.046, 1.2, { pan: (i % 2 ? 0.35 : -0.35) * (i / tones.length) })));
      },
      // Four: an Am7 pad swells while glass tones rise through A minor.
      quad() {
        const pad = [57, 64, 67, 72].map((m) => this.air(m, 0, 0.045, 2.2, { a: 0.3, rv: 0.22 }));
        const run = [69, 72, 76, 79, 81, 83, 84, 88].map((m, i) => this.glass(m, i * 0.06, 0.06, 1.3, { pan: i % 2 ? 0.4 : -0.4 }));
        return pad.concat(run);
      },
      // A T-spin: a quicker, wavering shimmer up an A minor chord.
      tspin() { return [this.air(64, 0, 0.04, 1.2)].concat([76, 81, 83, 88].map((m, i) => this.glass(m, i * 0.07, 0.062, 1.0, { vib: 10, pan: i % 2 ? 0.3 : -0.3 }))); },
      // A perfect clear: C major 9, the relative major, opening under a long bloom.
      perfect() {
        const pad = [60, 64, 67, 71, 74].map((m) => this.air(m, 0, 0.026, 2.8, { a: 0.4, rv: 0.24 }));
        return pad.concat([69, 72, 76, 79, 83, 84, 88].map((m, i) => this.keys(m, i * 0.08, 0.042, 1.6, { pan: i % 2 ? 0.35 : -0.35 })));
      },
      combo(s, n) { return [this.glass(69 + AM[Math.min(9, n || 1)], 0, 0.045, 0.6)]; },
      // A soft, low thoom: a falling sine and a dark puff of air.
      boom() { return [{ f: 98, to: 41, d: 0.8, g: 0.12, a: 0.01 }, { n: 1, d: 0.6, g: 0.09, q: 320 }, this.air(45, 0, 0.05, 1.2, { rv: 0.12 })]; },
      drill() { return [{ n: 1, d: 0.4, g: 0.04, fe: [1400, 300] }, { f: 110, to: 82, d: 0.4, g: 0.025 }]; },
      buy() { return [this.glass(76, 0, 0.11, 0.5, { fm: [2, 0.6, 0.2] }), this.glass(81, 0.08, 0.11, 0.7, { fm: [2, 0.6, 0.2] })]; },
      error() { return [{ f: hz(52), to: hz(50), d: 0.25, g: 0.045, q: 700 }]; },
      solve() { return [this.air(57, 0, 0.075, 1.8)].concat([69, 72, 76, 79, 83, 84].map((m, i) => this.keys(m, i * 0.07, 0.085, 1.5, { pan: i % 2 ? 0.35 : -0.35 }))); },
      fail() { return [this.air(76, 0, 0.034, 0.6, { to: hz(69), a: 0.03, q: 1500 })]; },
      golden() { return [81, 84, 88, 84, 88].map((m, i) => this.glass(m, i * 0.06, 0.075, 0.7)); },
      item() { return [this.drop(64, 0, 0.05, 0.25, { to: hz(69) }), this.glass(81, 0.08, 0.02, 0.4)]; },
      // The factory line, heard only while you watch it: a muffled press, a droplet onto the belt, a soft key as a piece
      // settles in the bin, and two quiet glass tones when the bin is full.
      stamp() { return [{ f: hz(45), d: 0.12, g: 0.05, a: 0.004, q: 400 }, { n: 1, d: 0.04, g: 0.012, q: 500 }]; },
      pack() { return [this.drop(69, 0, 0.03, 0.12), { n: 1, d: 0.03, g: 0.01, q: 900 }]; },
      land() { return [this.keys(64, 0, 0.03, 0.35, { dt: 0, rv: 0.12 }), { n: 1, d: 0.05, g: 0.015, q: 600 }]; },
      bell() { return [this.glass(81, 0, 0.04, 1.2), this.glass(88, 0.14, 0.03, 1.4)]; },
    },

    // A desk-bound machine: clicks, clacks, the carriage return's zip and its bell.
    typewriter: {
      base: 300, wave: 'triangle', decay: 0.15,
      move: () => [{ n: 1, d: 0.018, g: 0.12, bp: 3600 }, { f: 190, d: 0.02, g: 0.05 }],
      rotate: () => [{ n: 1, d: 0.02, g: 0.12, bp: 2800 }, { n: 1, d: 0.015, g: 0.08, bp: 4200, at: 0.03 }],
      lower: () => [{ n: 1, d: 0.04, g: 0.1, q: 900 }],
      lock: () => [{ n: 1, d: 0.07, g: 0.28, q: 1300 }, { f: 88, d: 0.08, g: 0.16 }, { f: 2400, d: 0.012, w: 'square', g: 0.015, at: 0.01 }],
      hold: () => [{ n: 1, d: 0.06, g: 0.14, q: 600 }, { n: 1, d: 0.02, g: 0.1, bp: 3000, at: 0.05 }],
      blocked: () => [{ n: 1, d: 0.06, g: 0.2, q: 500 }],
      clear: (s, n) => {
        const out = [{ n: 1, d: 0.26, g: 0.1, fe: [700, 5000], bp: 0 }];
        for (let i = 0; i < Math.min(n || 1, 4); i++) out.push({ f: 2093, d: 0.9, g: 0.06, at: 0.26 + i * 0.12, p: [[2.76, 0.4, 0.4], [5.4, 0.15, 0.2]] });
        return out;
      },
      quad: () => [{ n: 1, d: 0.3, g: 0.12, fe: [600, 6000] }, { f: 2093, d: 1, g: 0.07, at: 0.3, p: [[2.76, 0.4, 0.4]] }, { f: 2637, d: 1, g: 0.06, at: 0.42, p: [[2.76, 0.4, 0.4]] }, { f: 3136, d: 1.2, g: 0.06, at: 0.54, p: [[2.76, 0.4, 0.4]] }],
      tspin: () => [0, 1, 2, 3, 4, 5].map((i) => ({ n: 1, d: 0.02, g: 0.12, bp: 2500 + i * 300, at: i * (0.07 - i * 0.008) })),
      combo: (s, n) => Array.from({ length: Math.min(8, (n || 1) + 1) }, (_, i) => ({ n: 1, d: 0.018, g: 0.1, bp: 3000, at: i * 0.035 })),
      perfect: () => [{ n: 1, d: 0.4, g: 0.12, fe: [500, 7000] }].concat([0, 1, 2].map((i) => ({ f: 2093, d: 1.2, g: 0.07, at: 0.4 + i * 0.18, p: [[2.76, 0.4, 0.4]] }))),
    },

    // An old handheld: square waves, a coin for a line, a power-up for four.
    chip: {
      base: 440, wave: 'square', decay: 0.12,
      move: () => [{ f: 880, d: 0.025, w: 'square', g: 0.03 }],
      rotate: () => [{ f: 1175, d: 0.03, w: 'square', g: 0.035, to: 1397 }],
      lower: () => [{ f: 440, d: 0.02, w: 'square', g: 0.025 }],
      lock: () => [{ f: 220, d: 0.07, w: 'triangle', g: 0.18, to: 70 }, { n: 1, d: 0.03, g: 0.05, hp: 2000 }],
      hold: () => [{ f: 660, d: 0.04, w: 'square', g: 0.05 }, { f: 990, d: 0.05, w: 'square', g: 0.05, at: 0.045 }],
      clear: (s, n) => {
        const out = [];
        for (let i = 0; i < Math.min(n || 1, 4); i++) { out.push({ f: 988, d: 0.07, w: 'square', g: 0.05, at: i * 0.14 }, { f: 1319, d: 0.2, w: 'square', g: 0.05, at: i * 0.14 + 0.07 }); }
        return out;
      },
      quad: () => [659, 784, 1319, 1047, 1175, 1568].map((f, i) => ({ f, d: 0.09, w: 'square', g: 0.05, at: i * 0.07 })),
      tspin: () => [{ f: 1568, to: 392, d: 0.18, w: 'square', g: 0.05 }, { f: 392, to: 1568, d: 0.18, w: 'square', g: 0.05, at: 0.18 }],
      combo: (s, n) => [{ f: note(880, Math.min(10, n || 1)), d: 0.06, w: 'square', g: 0.05 }, { f: note(880, Math.min(12, (n || 1) + 2)), d: 0.08, w: 'square', g: 0.05, at: 0.06 }],
      perfect: () => [523, 659, 784, 1047, 784, 1047, 1319, 1568].map((f, i) => ({ f, d: 0.12, w: 'square', g: 0.05, at: i * 0.09 })),
    },

    // Everything goes bloop.
    bubbles: {
      base: 520, wave: 'sine', decay: 0.18, slide: true,
      move: () => [{ f: rand(460, 560), d: 0.05, g: 0.06, to: 900 }],
      rotate: () => [{ f: 700, d: 0.07, g: 0.07, to: 1400 }],
      lower: () => [{ f: 380, d: 0.05, g: 0.05, to: 620 }],
      lock: () => [{ f: 150, d: 0.14, g: 0.24, to: 460 }, { f: 900, d: 0.04, g: 0.03, to: 1600, at: 0.1 }],
      hold: () => [{ f: 600, d: 0.12, g: 0.1, to: 1600 }, { f: 1600, d: 0.1, g: 0.06, to: 600, at: 0.12 }],
      clear: (s, n) => Array.from({ length: 4 * Math.min(n || 1, 4) }, (_, i) => ({ f: rand(300, 700), to: rand(1200, 2400), d: 0.07 + Math.random() * 0.05, g: 0.05, at: i * 0.045 + Math.random() * 0.02 })),
      quad: () => Array.from({ length: 18 }, (_, i) => ({ f: rand(300, 900), to: rand(1400, 3000), d: 0.08, g: 0.05, at: i * 0.035 })).concat([{ n: 1, d: 0.05, g: 0.1, bp: 2000, at: 0.66 }]),
      tspin: () => [{ f: 500, to: 1800, d: 0.2, g: 0.07 }, { f: 1800, to: 400, d: 0.2, g: 0.07, at: 0.2 }, { f: 400, to: 2200, d: 0.25, g: 0.07, at: 0.4 }],
      combo: (s, n) => [{ f: 400 + (n || 1) * 90, to: 1400 + (n || 1) * 180, d: 0.09, g: 0.07 }],
    },

    // Wooden bars, a soft mallet: a roll for every clear.
    marimba: {
      base: 330, wave: 'sine', decay: 0.4,
      mallet: (f, at, g, d) => ({ f, d: d || 0.4, g, at, a: 0.002, q: 3500, p: [[4, 0.35, 0.15], [9.2, 0.08, 0.06]] }),
      move() { return [this.mallet(988, 0, 0.05, 0.12)]; },
      rotate() { return [this.mallet(1319, 0, 0.06, 0.15)]; },
      lower() { return [this.mallet(659, 0, 0.04, 0.12)]; },
      lock() { return [this.mallet(131, 0, 0.22, 0.5), this.mallet(262, 0.005, 0.06, 0.3)]; },
      hold() { return [this.mallet(523, 0, 0.1, 0.25), this.mallet(784, 0.07, 0.08, 0.25)]; },
      clear(s, n) { const out = []; const ch = [523, 659, 784, 1047]; for (let r = 0; r < 2 + Math.min(n || 1, 4) * 2; r++) out.push(this.mallet(ch[r % ch.length] * (r >= 4 ? 2 : 1), r * 0.06, 0.07, 0.5)); return out; },
      quad() { const out = []; for (let r = 0; r < 16; r++) out.push(this.mallet([523, 659, 784, 988][r % 4] * (1 + Math.floor(r / 8)), r * 0.045, 0.06, 0.6)); return out; },
      tspin() { return [this.mallet(784, 0, 0.08), this.mallet(622, 0.08, 0.08), this.mallet(1047, 0.16, 0.08, 0.6)]; },
      combo(s, n) { return [this.mallet(note(523, Math.min(10, n || 1)), 0, 0.08, 0.35)]; },
    },

    // Filtered saws with some weight: plucks, a bass thump, chord stabs that open up.
    synth: {
      base: 262, wave: 'sawtooth', decay: 0.25, filter: 2400,
      move: () => [{ f: 523, d: 0.05, w: 'sawtooth', g: 0.035, fe: [3000, 400] }],
      rotate: () => [{ f: 784, d: 0.06, w: 'sawtooth', g: 0.04, fe: [4000, 500] }],
      lower: () => [{ f: 392, d: 0.04, w: 'sawtooth', g: 0.025, fe: [1500, 300] }],
      lock: () => [{ f: 65, d: 0.3, w: 'sawtooth', g: 0.2, fe: [1400, 120] }, { f: 65, d: 0.3, w: 'sine', g: 0.15 }],
      hold: () => [{ f: 392, d: 0.18, w: 'sawtooth', g: 0.07, to: 587, fe: [600, 3500], dt: 12 }],
      clear: (s, n) => { const ch = [262, 330, 392, 494].slice(0, 2 + Math.min(n || 1, 2)); return ch.map((f) => ({ f, d: 0.55, w: 'sawtooth', g: 0.05, fe: [5000, 500], dt: 14 })); },
      quad: () => [131, 262, 330, 392, 494].map((f) => ({ f, d: 1.4, w: 'sawtooth', g: 0.045, a: 0.05, fe: [300, 6000], dt: 16 })),
      tspin: () => [{ f: 523, to: 784, d: 0.35, w: 'sawtooth', g: 0.06, fe: [1200, 4000], vib: 30 }],
      combo: (s, n) => [{ f: note(523, Math.min(10, n || 1)), d: 0.12, w: 'sawtooth', g: 0.05, fe: [5000, 600] }],
    },

    // Wine glasses: high, inharmonic, ringing long.
    glass: {
      base: 587, wave: 'sine', decay: 1.1, reverb: 0.35,
      tap: (f, at, g, d) => ({ f, d: d || 1, g, at, a: 0.002, p: [[2.76, 0.35, 0.5], [5.4, 0.12, 0.25], [8.93, 0.05, 0.12]], rv: 0.35 }),
      move() { return [this.tap(2093, 0, 0.018, 0.25)]; },
      rotate() { return [this.tap(2637, 0, 0.022, 0.35)]; },
      lower() { return [this.tap(1760, 0, 0.015, 0.2)]; },
      lock() { return [this.tap(1047, 0, 0.09, 1.1), this.tap(1051, 0, 0.04, 1.1)]; },
      hold() { return [this.tap(1568, 0, 0.06, 0.8)]; },
      clear(s, n) { return [0, 2, 4, 7, 9, 12, 14].slice(0, 3 + Math.min(n || 1, 4)).map((st, i) => this.tap(note(1047, st), i * 0.04, 0.045, 1.4)); },
      quad() { return [0, 2, 4, 7, 9, 12, 14, 16, 19, 21].map((st, i) => this.tap(note(1047, st), i * 0.035, 0.04, 1.8)); },
      tspin() { return [this.tap(2349, 0, 0.05), this.tap(1760, 0.1, 0.05), this.tap(3136, 0.2, 0.05, 1.4)]; },
      combo(s, n) { return [this.tap(note(1568, Math.min(10, n || 1)), 0, 0.045, 0.9)]; },
    },

    // Every move a random note from one calm scale, ringing into a wide space.
    chimes: {
      base: 523, wave: 'sine', decay: 1.4, reverb: 0.7,
      move: () => [{ f: note(1047, rand(0, 5)), d: 0.4, g: 0.022, rv: 0.7 }],
      rotate: () => [{ f: note(1047, rand(3, 8)), d: 0.5, g: 0.026, rv: 0.7 }],
      lower: () => [{ f: note(784, rand(0, 4)), d: 0.3, g: 0.018, rv: 0.7 }],
      lock: () => [{ f: note(262, rand(0, 4)), d: 1.2, g: 0.11, p: [[3, 0.2, 0.4]], rv: 0.6 }],
      hold: () => [{ f: note(784, rand(4, 9)), d: 0.9, g: 0.06, rv: 0.8 }],
      clear: (s, n) => Array.from({ length: 3 * Math.min(n || 1, 4) }, (_, i) => ({ f: note(1047, rand(0, 10)), d: 1.6, g: 0.04, at: i * 0.07 + Math.random() * 0.05, rv: 0.85 })),
      quad: () => Array.from({ length: 16 }, (_, i) => ({ f: note(784, rand(0, 13)), d: 2, g: 0.035, at: i * 0.06 + Math.random() * 0.04, rv: 0.9 })),
      tspin: () => [{ f: note(1047, 9), d: 1.4, g: 0.05, rv: 0.8 }, { f: note(1047, 4), d: 1.4, g: 0.05, at: 0.15, rv: 0.8 }, { f: note(1047, 12), d: 1.6, g: 0.05, at: 0.3, rv: 0.8 }],
    },
  };

  const Sound = {
    ctx: null,
    enabled: true,
    volume: 0.35,
    pack: 'soft',
    master: null,
    muted: false,
    lastAt: {},
    PACKS,

    ensure() {
      if (this.ctx) return this.ctx;
      const AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return null;
      try { this.wire(new AC()); } catch (e) { this.ctx = null; }
      return this.ctx;
    },

    /** The master chain and the shared room, on a context (a live one, or an offline one for a render). */
    wire(ctx) {
      this.ctx = ctx;
      this.master = ctx.createGain();
      const comp = ctx.createDynamicsCompressor();
      // Mute sits last, after everything, so nothing that sets a level elsewhere can undo it.
      this.muteGain = ctx.createGain(); this.muteGain.gain.value = this.muted ? 0 : 1;
      this.master.connect(comp).connect(this.muteGain).connect(ctx.destination);
      // A shared room: a soft, dark, two-and-a-half-second tail.
      const len = Math.floor(ctx.sampleRate * 2.6);
      const ir = ctx.createBuffer(2, len, ctx.sampleRate);
      for (let c = 0; c < 2; c++) {
        const d = ir.getChannelData(c);
        let lp = 0;
        for (let i = 0; i < len; i++) { lp = lp * 0.6 + (Math.random() * 2 - 1) * 0.4; d[i] = lp * Math.pow(1 - i / len, 2.6); }
      }
      this.reverb = ctx.createConvolver();
      this.reverb.buffer = ir;
      const wet = ctx.createGain(); wet.gain.value = 0.9;
      this.reverb.connect(wet).connect(this.master);
    },

    /**
     * Renders into an OfflineAudioContext instead of the speakers (scripts/audio-render.cjs measures sounds this way):
     * fn schedules on the offline context, then the live one comes back. Resolves to the AudioBuffer.
     */
    offline(seconds, fn, rate) {
      const OAC = root.OfflineAudioContext || root.webkitOfflineAudioContext;
      rate = rate || 44100;
      const ctx = new OAC(2, Math.ceil(seconds * rate), rate);
      const saved = [this.ctx, this.master, this.reverb, this.muteGain];
      try { this.wire(ctx); this.muteGain.gain.value = 1; this.master.gain.value = this.volume; fn(ctx); } finally { [this.ctx, this.master, this.reverb, this.muteGain] = saved; }
      return ctx.startRendering();
    },

    rnd(a, b) { return rand(a, b); },

    voice(v, when, pack) {
      const ctx = this.ctx;
      pack = pack || {};
      const t = ctx.currentTime + (when || 0) + (v.at || 0);
      const g = ctx.createGain();
      const peak = Math.max(0.0001, (v.g == null ? 0.15 : v.g));
      const a = v.a != null ? v.a : pack.attack || 0.005;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(peak, t + a);
      g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(v.d, a + 0.01));
      let out = g;
      const filt = (type, freq) => { const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; out.connect(f); out = f; return f; };
      if (v.q) filt('lowpass', v.q);
      if (v.hp) filt('highpass', v.hp);
      if (v.bp) { const f = filt('bandpass', v.bp); f.Q.value = 3; }
      if (v.fe) { const f = filt('lowpass', v.fe[0]); f.frequency.setValueAtTime(v.fe[0], t); f.frequency.exponentialRampToValueAtTime(v.fe[1], t + v.d); f.Q.value = 4; }
      if (v.pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = v.pan; out.connect(p); out = p; }
      out.connect(this.master);
      const rv = v.rv != null ? v.rv : pack.reverb || 0;
      if (rv && this.reverb) { const s = ctx.createGain(); s.gain.value = rv; out.connect(s).connect(this.reverb); }
      if (v.n) {
        const len = Math.max(1, Math.floor(ctx.sampleRate * v.d));
        const buf = ctx.createBuffer(1, len, ctx.sampleRate);
        const data = buf.getChannelData(0);
        for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
        const src = ctx.createBufferSource(); src.buffer = buf; src.connect(g); src.start(t);
        return;
      }
      const osc = (freq, detune) => {
        const o = ctx.createOscillator();
        o.type = v.w || pack.wave || 'sine';
        o.frequency.setValueAtTime(freq, t);
        if (detune) o.detune.value = detune;
        if (v.to) o.frequency.exponentialRampToValueAtTime(v.to * (freq / v.f), t + v.d);
        if (v.vib) {
          const lfo = ctx.createOscillator(), lg = ctx.createGain();
          lfo.frequency.value = 5.2; lg.gain.value = v.vib;
          lfo.connect(lg).connect(o.detune); lfo.start(t); lfo.stop(t + v.d + 0.05);
        }
        o.start(t); o.stop(t + v.d + 0.05);
        return o;
      };
      const main = osc(v.f, 0);
      main.connect(g);
      if (v.fm) {
        const [ratio, index, share] = v.fm, m = ctx.createOscillator(), mg = ctx.createGain();
        m.frequency.value = v.f * ratio;
        mg.gain.setValueAtTime(v.f * index, t);
        mg.gain.exponentialRampToValueAtTime(Math.max(0.01, v.f * index * 0.02), t + Math.max(0.02, v.d * (share || 0.3)));
        m.connect(mg).connect(main.frequency); m.start(t); m.stop(t + v.d + 0.05);
      }
      const dt = v.dt != null ? v.dt : 0;
      if (dt) { const g2 = ctx.createGain(); g2.gain.value = 0.6; osc(v.f, dt).connect(g2).connect(g); }
      const partials = v.p || (v.h ? [[v.h, 0.25, 0.4]] : null);
      if (partials) {
        for (const [mul, lvl, share] of partials) {
          const o2 = ctx.createOscillator(), g2 = ctx.createGain();
          o2.frequency.value = v.f * mul;
          g2.gain.setValueAtTime(0.0001, t);
          g2.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak * lvl), t + a);
          g2.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(0.02, v.d * share));
          if (out !== g) g2.connect(out);
          else {
            g2.connect(this.master);
            if (rv && this.reverb) { const s = ctx.createGain(); s.gain.value = rv; g2.connect(s).connect(this.reverb); }
          }
          o2.connect(g2); o2.start(t); o2.stop(t + v.d + 0.05);
        }
      }
    },

    /** Events every pack shares, voiced in the pack's wave, scale and room. */
    common(pack, name, arg) {
      const w = pack.wave || 'triangle', dec = pack.decay || 0.22, base = pack.base || 392, q = pack.filter;
      const arp = (steps, gap, g, d) => steps.map((st, i) => ({ f: note(base, st), d: d || dec, w, g, at: i * gap, q }));
      switch (name) {
        case 'clear': { const n = Math.min(arg || 1, 4); return arp([0, 2, 4, 5, 7].slice(0, n + 1), 0.05, 0.12); }
        case 'quad': return arp([0, 2, 4, 5, 7, 10], 0.05, 0.13);
        case 'perfect': return arp([0, 2, 4, 5, 7, 9, 10], 0.06, 0.14, dec * 1.6);
        case 'tspin': return arp([4, 2, 5], 0.06, 0.12);
        case 'combo': return [{ f: note(base * 2, Math.min(10, arg || 1)), d: 0.1, w, g: 0.08, q }];
        case 'blocked': return [{ f: 140, d: 0.05, w: 'triangle', g: 0.04, q: 700 }];
        case 'buy': return arp([4, 7], 0.06, 0.1);
        case 'error': return [{ f: 196, d: 0.18, w: 'triangle', g: 0.07, q: 900, to: 150 }];
        case 'solve': return arp([0, 2, 4, 7, 9], 0.08, 0.11, dec * 1.8);
        case 'fail': return [{ f: note(base, 4), d: 0.35, w, g: 0.08, to: note(base, 0) * 0.8 }];
        case 'boom': return [{ n: 1, d: 0.5, g: 0.3, q: 450 }, { f: 90, d: 0.45, w: 'sine', g: 0.22, to: 38 }];
        case 'drill': return [{ n: 1, d: 0.35, g: 0.1, q: 2500 }];
        case 'golden': return arp([7, 9, 10, 9, 10], 0.05, 0.08);
        case 'pack': return [{ f: note(base * 2, 5), d: 0.1, w, g: 0.06 }, { n: 1, d: 0.03, g: 0.03, q: 1800 }];
        case 'stamp': return [{ n: 1, d: 0.05, g: 0.03, q: 600 }];
        case 'item': return [{ f: note(base, 4), d: 0.2, w: 'sine', g: 0.08, to: note(base, 7) }];
        case 'bell': return [{ f: 1568, d: 0.6, w: 'sine', g: 0.06, h: 2.4 }, { f: 1568, d: 0.5, w: 'sine', g: 0.04, at: 0.12, h: 2.4 }];
        case 'land': return [{ n: 1, d: 0.05, g: 0.05, q: 700 }];
        default: return null;
      }
    },

    /** The voices a pack makes for an event (its own, or the shared ones). */
    voices(name, arg, packId) {
      const pack = PACKS[packId || this.pack] || PACKS.soft;
      return { pack, list: typeof pack[name] === 'function' ? pack[name](this, arg) : this.common(pack, name, arg) };
    },

    play(name, arg, packId) {
      if (!this.enabled && !packId) return;
      const ctx = this.ensure();
      if (!ctx) return;
      if (ctx.state === 'suspended') ctx.resume();
      // A burst of the same sound in one frame (auto-repeat, a flurry of events) plays once.
      const now = performance.now();
      if (now - (this.lastAt[name] || 0) < 28) return;
      this.lastAt[name] = now;
      this.master.gain.value = this.volume;
      if (this.muted) return; // nobody would hear it: skip building it
      const { pack, list } = this.voices(name, arg, packId);
      if (!list) return;
      // With Classic's music playing, tuned to the chord of the moment (and a big one perhaps nudged onto the beat).
      const plan = Harmony.plan(name, list, ctx.currentTime);
      for (const v of plan.list) this.voice(v, plan.delay, pack);
    },

    /** Silences everything at once — notes already ringing too — with a short ramp so it does not click. The levels
     * underneath (effects, music, announcer) are left alone, so unmuting brings back exactly what was there. */
    setMuted(on) {
      this.muted = !!on;
      const g = this.muteGain;
      if (!g) return;
      const t = this.ctx.currentTime;
      g.gain.cancelScheduledValues(t);
      // A context not yet running has frozen time: a ramp would still be under way when it wakes, so set it outright.
      if (this.ctx.state !== 'running') { g.gain.value = this.muted ? 0 : 1; return; }
      g.gain.setValueAtTime(g.gain.value, t);
      g.gain.linearRampToValueAtTime(this.muted ? 0 : 1, t + 0.05);
    },

    /** A short phrase that shows off a pack (Shop preview). */
    preview(packId) {
      const seq = [['move', 0], ['move', 0.09], ['rotate', 0.2], ['lower', 0.34], ['lower', 0.42], ['lock', 0.55], ['clear', 0.85, 2], ['quad', 2.0]];
      for (const [n, at, arg] of seq) setTimeout(() => { this.lastAt[n] = 0; this.play(n, arg, packId); }, at * 1000);
    },
  };

  // ---- Classic's music: Korobeiniki (a 19th-century Russian folk song, public domain), slowed and dreamed -----------
  //
  // The tune as written, in its own key (A minor), taken down to 80 and dressed like a late-night console menu: a
  // glassy FM electric piano over wide, slowly filtered pads of extended chords (min9, min11, maj9 on the relative
  // major), a warm sub, a quiet arpeggio in places, all on a faint tape wobble with chorus, a dark echo and the shared
  // room. A three-minute suite, so it rarely repeats: pads and arpeggio; the theme; the theme with a harmony and a soft
  // beat; the bridge floating at half time; an interlude with its counter-melody on glass; the theme over a low
  // counter-line; the bridge in time; and a short coda that breathes before it goes round again (from the theme).
  //
  // Korobeiniki's A part in A minor, in eighths, as everyone knows it (scripts/test.cjs checks TUNE_A against this):
  //   E5 2  B4 1  C5 1  D5 2  C5 1  B4 1 | A4 2  A4 1  C5 1  E5 2  D5 1  C5 1 | B4 3  C5 1  D5 2  E5 2 | C5 2  A4 2  A4 4
  //   rest 1  D5 2  F5 1  A5 2  G5 1  F5 1 | E5 3  C5 1  E5 2  D5 1  C5 1 | B4 2  B4 1  C5 1  D5 2  E5 2 | C5 2  A4 2  A4 2  rest 2
  // and its B part: E5 4 C5 4 | D5 4 B4 4 | C5 4 A4 4 | G#4 4 B4 2 rest 2 | E5 4 C5 4 | D5 4 B4 4 | C5 2 E5 2 A5 4 | G#5 8

  const MIDI = (n) => { // 'E5', 'C#4', '-' (rest)
    if (n === '-') return null;
    const m = /^([A-G])(#?)(\d)$/.exec(n);
    return { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[m[1]] + (m[2] ? 1 : 0) + (Number(m[3]) + 1) * 12;
  };
  // A line in eighths, cut into bars of eight; a note held over a bar line stays in the bar it starts in.
  const bars = (str) => {
    const out = [];
    let len = 0;
    for (const t of str.split(',')) {
      const [n, l] = t.trim().split(' ');
      while (out.length <= Math.floor(len / 8)) out.push([]);
      out[Math.floor(len / 8)].push([MIDI(n), Number(l)]);
      len += Number(l);
    }
    while (out.length < len / 8) out.push([]);
    return out;
  };
  // Every note twice as long: a line at half time, over twice the bars.
  const slow = (str) => str.split(',').map((t) => { const [n, l] = t.trim().split(' '); return n + ' ' + l * 2; }).join(',');
  const A_PART = 'E5 2,B4 1,C5 1,D5 2,C5 1,B4 1,A4 2,A4 1,C5 1,E5 2,D5 1,C5 1,B4 3,C5 1,D5 2,E5 2,C5 2,A4 2,A4 4,- 1,D5 2,F5 1,A5 2,G5 1,F5 1,E5 3,C5 1,E5 2,D5 1,C5 1,B4 2,B4 1,C5 1,D5 2,E5 2,C5 2,A4 2,A4 2,- 2';
  const B_PART = 'E5 4,C5 4,D5 4,B4 4,C5 4,A4 4,G#4 4,B4 2,- 2,E5 4,C5 4,D5 4,B4 4,C5 2,E5 2,A5 4,G#5 8';
  const TUNE_A = bars(A_PART);
  const TUNE_B = bars(B_PART);
  const TUNE_B_SLOW = bars(slow(B_PART));
  // The interlude's counter-melody (over PROG_I), and a low line that moves under the theme in the variation.
  const COUNTER = bars('A5 6,G5 2,G5 8,F5 6,E5 2,D5 8,C5 6,D5 2,E5 8,D5 4,C5 4,B4 8');
  const UNDER = bars('B3 8,C4 8,D4 4,B3 4,C4 4,E4 4,F4 8,E4 8,D4 4,B3 4,C4 8');
  // Chords: [bass, pad voicing]. Extended and voiced close, under the tune; the dominant keeps its G# only where the
  // bridge's melody has one.
  const CH = {
    Am9: [45, [55, 59, 60, 64]], Am11: [45, [55, 60, 62, 64]], Em11: [40, [55, 57, 62, 64]], E9: [40, [56, 59, 62, 66]],
    Dm9: [38, [53, 57, 60, 64]], Cmaj9: [36, [55, 59, 62, 64]], Fmaj9: [41, [57, 60, 64, 67]], Esus: [40, [57, 59, 62, 64]],
  };
  const PROG_A = ['Em11', 'Am9', 'Em11', 'Am9', 'Dm9', 'Cmaj9', 'Em11', 'Am9'];
  const PROG_V = ['Em11', 'Am9', 'Em11', 'Am9', 'Dm9', 'Fmaj9', 'Em11', 'Am11'];
  const PROG_B = ['Am9', 'E9', 'Am9', 'E9', 'Am9', 'E9', 'Am9', 'E9'];
  const PROG_I = ['Fmaj9', 'Em11', 'Dm9', 'Esus', 'Fmaj9', 'Em11', 'Dm9', 'E9'];
  const DRIFT = ['Fmaj9', 'Em11', 'Dm9', 'Esus'];
  // Arpeggio shapes, as indexes into the voicing, one per eighth.
  const ARPS = { rise: [0, 1, 2, 3, 0, 1, 2, 3], wave: [0, 2, 1, 3, 2, 1, 3, 1], fall: [3, 2, 1, 0, 3, 2, 1, 2] };

  // hold: bars per chord (2 = half time) · arp and arpUp (semitones) · groove: 0 none, 1 a soft kick, 2 kick and brush
  const SECTIONS = [
    { name: 'intro', prog: DRIFT, arp: 'rise', arpUp: 12, bells: true, once: true },
    { name: 'theme', prog: PROG_A, lead: TUNE_A, voice: 'keys', bells: true },
    { name: 'theme2', prog: PROG_A, lead: TUNE_A, voice: 'keys', harmony: true, arp: 'wave', groove: 2 },
    { name: 'float', prog: PROG_B, hold: 2, lead: TUNE_B_SLOW, voice: 'breath', drops: true, bells: true, groove: 1 },
    { name: 'interlude', prog: PROG_I, lead: COUNTER, voice: 'glass', arp: 'rise', groove: 1 },
    { name: 'variation', prog: PROG_V, lead: TUNE_A, voice: 'keys', under: UNDER, groove: 2 },
    { name: 'bridge', prog: PROG_B, lead: TUNE_B, voice: 'keys', harmony: true, arp: 'wave', groove: 2, bells: true },
    { name: 'coda', prog: DRIFT, arp: 'fall', arpUp: 12, drops: true, bells: true },
  ];
  const SONG = (() => {
    const list = [];
    SECTIONS.forEach((s, si) => {
      const hold = s.hold || 1;
      s.prog.forEach((c, ci) => {
        for (let k = 0; k < hold; k++) {
          const b = ci * hold + k;
          list.push({
            section: s.name, si, name: c, harm: CH[c], chord: k === 0 ? CH[c] : null, hold, left: hold - k, lead: s.lead ? s.lead[b] : null,
            under: s.under ? s.under[b] : null, voice: s.voice, harmony: !!s.harmony, arp: s.arp || null, arpUp: s.arpUp || 0,
            groove: s.groove || 0, bells: !!s.bells, drops: !!s.drops, once: !!s.once,
          });
        }
      });
    });
    return { bars: list, loopFrom: list.findIndex((b) => !b.once), tunes: { A: TUNE_A, B: TUNE_B, slowB: TUNE_B_SLOW }, chords: CH };
  })();

  // A harmony under the tune: the nearest note of the bar's chord a third to a sixth below, so it never rubs.
  function harmonyBelow(m, chord) {
    const pcs = [chord[0]].concat(chord[1]).map((x) => x % 12);
    for (let d = 3; d <= 9; d++) if (pcs.includes((m - d) % 12)) return m - d;
    return m - 5;
  }

  /**
   * Classic's music. The tempo stays put; only a stack near the top quickens it (tempo, set by Classic).
   */
  const Music = {
    playing: false,
    volume: 0.25,
    tempo: 1,
    bpm: 80,
    timer: null,
    gain: null,
    live: 0, // oscillators scheduled and not yet ended

    start() {
      const ctx = Sound.ensure();
      if (!ctx || this.playing) return;
      if (ctx.state === 'suspended') ctx.resume();
      this.playing = true;
      this.on = ctx;
      this.wire(ctx);
      Sound.master.gain.value = Sound.volume; // a Volume of 0 is a real 0
      this.pos = { bar: this.pos && this.pos.bar != null ? this.pos.bar : 0, at: ctx.currentTime + 0.1 };
      this.fresh = true;
      this.timer = setInterval(() => this.schedule(), 60);
      this.schedule();
    },

    /**
     * The mixing desk, built per start: instruments → tape wobble → a slowly moving low-pass → the volume (which the
     * announcer ducks) → the speakers, a chorus either side, a dark dotted-eighth echo, and the shared room (with the
     * bass kept out of it so the tail stays clear). Pads have their own wide, breathing filter.
     */
    wire(ctx) {
      const lfos = this.lfos = [], sends = this.sends = [];
      const lfo = (f, depth, param) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = f; g.gain.value = depth; o.connect(g).connect(param); o.start(); lfos.push(o); };
      const pan = (v, dest) => { const p = ctx.createStereoPanner(); p.pan.value = v; p.connect(dest); return p; };
      this.bus = ctx.createGain();
      // Tape: a short delay whose length sways slowly (wow, about five cents) and a little faster (flutter).
      const tape = ctx.createDelay(0.1);
      tape.delayTime.value = 0.012;
      lfo(0.29, 0.0016, tape.delayTime); lfo(4.7, 0.00005, tape.delayTime);
      const tone = ctx.createBiquadFilter();
      tone.type = 'lowpass'; tone.frequency.value = 3600; tone.Q.value = 0.4;
      lfo(0.023, 700, tone.frequency);
      this.gain = ctx.createGain();
      this.gain.gain.value = this.volume;
      this.bus.connect(tape).connect(tone).connect(this.gain);
      this.gain.connect(Sound.master);
      // Chorus: two slowly swaying copies, one each side.
      for (const [t, f, side] of [[0.021, 0.19, -0.7], [0.027, 0.13, 0.7]]) {
        const d = ctx.createDelay(0.1), g = ctx.createGain();
        d.delayTime.value = t; lfo(f, 0.003, d.delayTime); g.gain.value = 0.3;
        this.gain.connect(d).connect(g).connect(pan(side, Sound.master));
        sends.push(g);
      }
      // Echo: a dotted eighth, darker on each repeat, and short-lived.
      const echo = this.echo = ctx.createDelay(2), fb = ctx.createGain(), elp = ctx.createBiquadFilter(), wet = ctx.createGain();
      echo.delayTime.value = 60 / this.bpm * 0.75; fb.gain.value = 0.28; elp.type = 'lowpass'; elp.frequency.value = 1700; wet.gain.value = 0.15;
      this.gain.connect(echo); echo.connect(elp); elp.connect(fb); fb.connect(echo); elp.connect(wet).connect(Sound.master);
      sends.push(wet);
      if (Sound.reverb) {
        const hp = ctx.createBiquadFilter(), rs = ctx.createGain();
        hp.type = 'highpass'; hp.frequency.value = 240; rs.gain.value = 0.3;
        this.gain.connect(hp).connect(rs).connect(Sound.reverb);
        sends.push(rs);
      }
      // Pads: left and right through a filter that opens and closes over about twenty seconds.
      const padF = ctx.createBiquadFilter(), padF2 = ctx.createBiquadFilter();
      padF.type = 'lowpass'; padF.frequency.value = 1100; padF.Q.value = 0.6;
      padF2.type = 'lowpass'; padF2.frequency.value = 2400; padF2.Q.value = 0.3;
      lfo(0.05, 450, padF.frequency);
      padF.connect(padF2).connect(this.bus);
      this.padL = pan(-0.55, padF); this.padR = pan(0.55, padF);
      // Either side of centre, for the arpeggio and the bells.
      this.left = pan(-0.35, this.bus); this.right = pan(0.35, this.bus);
    },

    /**
     * Inside Sound.offline: the suite from a bar, for some seconds, onto the offline context. Its timeline stays behind
     * (rendered) so sound effects played onto the same context fit its chords; silent keeps the time without the notes.
     */
    render(ctx, seconds, bar, silent) {
      const keep = ['gain', 'bus', 'lfos', 'sends', 'echo', 'padL', 'padR', 'left', 'right', 'pos', 'playing', 'fresh'].map((k) => [k, this[k]]);
      this.wire(ctx);
      this.playing = true;
      this.pos = { bar: bar || 0, at: 0.05, keep: Infinity };
      this.fresh = true;
      this.fill(seconds, silent);
      this.rendered = { ctx, sched: this.pos.sched, e: 60 / (this.bpm * this.tempo) / 2 };
      for (const [k, v] of keep) this[k] = v;
    },

    /** The bars scheduled on the current context, with the eighth they will go on at: the live music's, or a render's. */
    timeline() {
      const ctx = Sound.ctx;
      if (!ctx) return null;
      if (this.rendered && this.rendered.ctx === ctx) return this.rendered;
      const p = this.pos;
      return this.playing && this.on === ctx && p && p.sched && p.sched.length ? { sched: p.sched, e: 60 / (this.bpm * this.tempo) / 2 } : null;
    },

    /**
     * The bar sounding at context time t: { idx, bar, at, e }. Bars go at the tempo they were scheduled at; past the
     * last one scheduled, the ones to come are counted on at the tempo now.
     */
    barAt(t, line) {
      line = line || this.timeline();
      if (!line || !line.sched || !line.sched.length) return null;
      let cur = line.sched[0];
      for (const b of line.sched) if (b.at <= t) cur = b;
      let idx = cur.bar, at = cur.at, e = cur.e || line.e;
      for (let k = 0; k < 64 && t >= at + 8 * e; k++) {
        at += 8 * e;
        idx = idx + 1 >= SONG.bars.length ? SONG.loopFrom : idx + 1;
        e = line.e || e;
      }
      return { idx, bar: SONG.bars[idx], at, e };
    },

    stop() {
      if (!this.playing) return;
      this.playing = false;
      clearInterval(this.timer);
      // Bars are scheduled whole and ahead: come back to the one that was sounding, not the one after it.
      const p = this.pos;
      if (p && p.sched && Sound.ctx) {
        const now = Sound.ctx.currentTime, cur = p.sched.filter((b) => b.at <= now).pop() || p.sched[0];
        if (cur) p.bar = cur.bar;
      }
      const g = this.gain, ctx = Sound.ctx, sends = this.sends || [], lfos = this.lfos || [];
      if (g && ctx) {
        g.gain.cancelScheduledValues(ctx.currentTime);
        g.gain.setTargetAtTime(0, ctx.currentTime, 0.08);
        setTimeout(() => { g.disconnect(); for (const s of sends) s.disconnect(); for (const o of lfos) { try { o.stop(); } catch (e) { /* done */ } } }, 700);
      }
      this.gain = null;
    },

    /** Back to the top (a new game). While playing, what was scheduled fades out and the suite starts again. */
    rewind() {
      const was = this.playing;
      if (was) this.stop();
      this.pos = null;
      if (was) this.start();
    },

    setVolume(v) { if (v === this.volume) return; this.volume = v; if (this.gain) this.gain.gain.value = v; },

    /** Dips the music a little while the announcer speaks, so the two do not fight. */
    duck(from, to) {
      const g = this.gain;
      if (!g) return;
      const p = g.gain, v = this.volume;
      p.cancelScheduledValues(from - 0.01);
      p.setTargetAtTime(v * 0.55, from - 0.01, 0.04);
      p.setTargetAtTime(v, to, 0.25);
    },

    // ---- instruments: every note is a few oscillators that stop on their own and are let go when they do ----------

    osc(type, f, at, end) {
      const o = Sound.ctx.createOscillator();
      o.type = type; o.frequency.value = f;
      o.start(at); o.stop(end);
      this.live++;
      o.onended = () => { this.live--; o.disconnect(); if (o.tail) for (const n of o.tail) n.disconnect(); };
      return o;
    },

    /** An envelope: in over attack, held to dur, then away with a time-constant of release. */
    env(o, at, dur, gain, attack, dest, release) {
      const g = Sound.ctx.createGain();
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(gain, at + attack);
      g.gain.setTargetAtTime(0.0001, at + Math.max(attack, dur), release || dur * 0.35 + 0.05);
      o.connect(g).connect(dest || this.bus);
      (o.tail = o.tail || []).push(g);
      return g;
    },

    /** A modulator on o's pitch whose depth (in Hz) falls from a to b over time. */
    fm(o, ratio, a, b, at, time, end) {
      const m = this.osc('sine', o.frequency.value * ratio, at, end), g = Sound.ctx.createGain();
      g.gain.setValueAtTime(a, at); g.gain.exponentialRampToValueAtTime(b, at + time);
      m.connect(g).connect(o.frequency);
      (m.tail = m.tail || []).push(g);
    },

    /** Electric piano, glass-edged: FM at one (the round body, bright then plain) and a brief high glint. */
    keys(f, at, dur, gain, dest) {
      const end = at + dur + 1.6, o = this.osc('sine', f, at, end);
      this.fm(o, 1, f * 1.1, f * 0.06, at, 0.8, end);
      this.fm(o, 7, f * 0.2, f * 0.003, at, 0.12, at + 0.3);
      const g = this.env(o, at, dur, gain, 0.012, dest, 0.28);
      g.gain.setTargetAtTime(gain * 0.45, at + 0.012, 0.2);
      g.gain.setTargetAtTime(0.0001, at + dur, 0.28);
    },

    /** A breathy lead: triangle and sine a hair apart, a slow swell and a vibrato that arrives late. */
    breath(f, at, dur, gain, dest) {
      const ctx = Sound.ctx, end = at + dur + 1.2;
      const a = this.osc('triangle', f, at, end), b = this.osc('sine', f, at, end), v = this.osc('sine', 4.6, at, end), vg = ctx.createGain();
      b.detune.value = 6;
      vg.gain.setValueAtTime(0, at); vg.gain.linearRampToValueAtTime(7, at + Math.min(0.8, dur));
      v.connect(vg); vg.connect(a.detune); vg.connect(b.detune);
      v.tail = [vg];
      this.env(a, at, dur, gain * 0.6, 0.16, dest, 0.3);
      this.env(b, at, dur, gain * 0.5, 0.2, dest, 0.3);
    },

    /** A glass bell: inharmonic FM that shimmers and fades over a few seconds. */
    bell(f, at, gain, dest) {
      const end = at + 4, o = this.osc('sine', f, at, end);
      this.fm(o, 3.5, f * 1.1, f * 0.02, at, 1.2, end);
      this.env(o, at, 0.01, gain, 0.004, dest, 0.9);
    },

    /** The arpeggio's soft digital pluck. */
    pluck(f, at, gain, dest) {
      const end = at + 1.2, o = this.osc('sine', f, at, end);
      this.fm(o, 2, f * 0.5, f * 0.02, at, 0.15, end);
      this.env(o, at, 0.01, gain, 0.004, dest, 0.2);
    },

    /** A water droplet: a sine that leaps up as it vanishes. */
    drop(f, at, gain, dest) {
      const o = this.osc('sine', f, at, at + 0.4);
      o.frequency.setValueAtTime(f, at); o.frequency.exponentialRampToValueAtTime(f * 1.6, at + 0.05);
      this.env(o, at, 0.01, gain, 0.003, dest, 0.04);
    },

    /** A pad note: two saws a few cents apart, one each side, swelling in and out slowly (each chord's swell
     * overlaps the last one's fade, so there is never a hole between them). */
    pad(m, at, len) {
      const end = at + len + 3;
      for (const [cents, side] of [[-7, this.padL], [7, this.padR]]) {
        const o = this.osc('sawtooth', hz(m), at, end), g = Sound.ctx.createGain();
        o.detune.value = cents;
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(0.011, at + 0.9);
        g.gain.setTargetAtTime(0, at + len - 0.3, 0.6);
        o.connect(g).connect(side);
        o.tail = [g];
      }
    },

    /** The bass: a round sine with a softer one an octave down under it. */
    bass(m, at, dur, gain) {
      const end = at + dur + 1.5;
      this.env(this.osc('sine', hz(m), at, end), at, dur, gain, 0.04, null, 0.3);
      this.env(this.osc('sine', hz(m - 12), at, end), at, dur, gain * 0.5, 0.06, null, 0.3);
    },

    /** A felt kick: low and short, no click. */
    kick(at, gain) {
      const o = this.osc('sine', 78, at, at + 0.6);
      o.frequency.setValueAtTime(78, at); o.frequency.exponentialRampToValueAtTime(46, at + 0.14);
      this.env(o, at, 0.02, gain, 0.005, null, 0.1);
    },

    /** A brush: a puff of mid-band noise, no top. */
    brush(at, gain) {
      const ctx = Sound.ctx;
      if (!this.noiseBuf || this.noiseBuf.sampleRate !== ctx.sampleRate) {
        const len = Math.floor(ctx.sampleRate * 0.4);
        this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
        const d = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      }
      const src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
      src.buffer = this.noiseBuf; f.type = 'bandpass'; f.frequency.value = 1100; f.Q.value = 1.4;
      g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(gain, at + 0.015); g.gain.setTargetAtTime(0.0001, at + 0.02, 0.06);
      src.connect(f).connect(g).connect(this.right);
      src.start(at); src.stop(at + 0.4);
      src.onended = () => { src.disconnect(); f.disconnect(); g.disconnect(); };
    },

    lead(voice, f, at, dur, gain) {
      if (voice === 'breath') this.breath(f, at, dur, gain * 0.8);
      else if (voice === 'glass') { this.bell(f, at, gain * 0.75, this.bus); this.breath(f, at, dur, gain * 0.3); }
      else this.keys(f, at, dur, gain);
    },

    /** One bar at a time, a little ahead, as Web Audio likes it. */
    schedule() {
      const ctx = Sound.ctx;
      if (!ctx || !this.playing) return;
      this.fill(ctx.currentTime + 0.35, Sound.muted);
    },

    /** Schedules bars up to a time. Silent (muted) keeps time without building notes; the next heard bar sounds its chord. */
    fill(until, silent) {
      const p = this.pos;
      if (!p) return;
      while (p.at < until) {
        const e = 60 / (this.bpm * this.tempo) / 2; // an eighth
        if (this.echo) this.echo.delayTime.setTargetAtTime(e * 1.5, p.at, 0.5);
        if (silent) this.fresh = true;
        else this.playBar(SONG.bars[p.bar], p.at, e, p.bar);
        // What was scheduled when, and how fast: stop() comes back to it, and sound effects find their chord in it.
        p.sched = (p.sched || []).concat({ bar: p.bar, at: p.at, e }).slice(-(p.keep || 3));
        p.at += e * 8;
        p.bar++;
        if (p.bar >= SONG.bars.length) p.bar = SONG.loopFrom;
      }
    },

    playBar(bar, t0, e, idx) {
      // A fixed scatter per bar, so bells and droplets land in the same places every time round.
      const rnd = (k) => { const x = Math.sin((idx * 8 + k) * 12.9898) * 43758.5453; return x - Math.floor(x); };
      const [root, voicing] = bar.harm;
      // A held chord sounds from its first bar; coming back (after a pause) in the middle of one, it sounds from here.
      const fresh = this.fresh;
      this.fresh = false;
      if (bar.chord || fresh) {
        const len = e * 8 * bar.left;
        for (const m of voicing) this.pad(m, t0, len);
        this.bass(root, t0, len - e * 0.5, 0.13);
      }
      if (bar.groove >= 2) this.bass(root + 12, t0 + e * 6, e * 1.5, 0.04);
      if (bar.arp) {
        ARPS[bar.arp].forEach((k, i) => this.pluck(hz(voicing[k] + bar.arpUp), t0 + i * e, 0.02, i % 2 ? this.right : this.left));
      }
      if (bar.bells && rnd(1) < 0.75) this.bell(hz(voicing[Math.floor(rnd(2) * 4)] + 12), t0 + e * 2 * Math.floor(rnd(3) * 4), 0.016, rnd(4) < 0.5 ? this.left : this.right);
      if (bar.drops) for (let i = 0; i < 2; i++) this.drop(hz(81 + AM[Math.floor(rnd(5 + i) * 5)]), t0 + e * Math.floor(rnd(7 + i) * 8), 0.012, i ? this.left : this.right);
      if (bar.groove >= 1 && (bar.chord || fresh)) this.kick(t0, 0.12);
      if (bar.groove >= 2) { this.kick(t0 + e * 5, 0.06); this.brush(t0 + e * 2, 0.018); this.brush(t0 + e * 6, 0.018); }
      if (bar.lead) {
        let at = t0;
        for (const [m, l] of bar.lead) {
          if (m != null) {
            this.lead(bar.voice, hz(m), at, l * e, 0.12);
            if (bar.harmony) this.keys(hz(harmonyBelow(m, bar.harm)), at, l * e, 0.04);
          }
          at += l * e;
        }
      }
      if (bar.under) {
        let at = t0;
        for (const [m, l] of bar.under) { if (m != null) this.breath(hz(m), at, l * e, 0.07); at += l * e; }
      }
    },
  };

  // ---- sound effects in the music's harmony --------------------------------------------------------------------------
  //
  // While Classic's music plays, every pitched voice of a sound effect (any pack, any event, and any added later) is
  // retuned to the chord sounding as it rings. The whole sound moves first — at most a tritone, so it keeps its register
  // — until its first note is a chord tone, by whichever move disturbs its other notes least; then every other note
  // goes to the nearest chord tone (a short blip of a note or two, the nearest note of the key), keeping the sound's shape: a rising run
  // still rises, a chord keeps its order, twins a few cents apart stay twins, slides keep their span and partials, FM
  // and detune ride along. Noise, clicks and low thuds or sweeps are left alone, and so is everything when the music is
  // not playing (the packs are already at home in A minor). The three big celebrations may wait for the next eighth of
  // the beat, but only when it is at most 60 ms off: audio that trails the picture by that little reads as together
  // (it is well inside the ~125 ms lag at which people notice, ITU-R BT.1359), and nothing you steer by — a move, a
  // turn, a lock — is ever held back.
  const Harmony = {
    QUANTIZE: 0.06, // longest wait for the beat, seconds
    CELEBRATE: { quad: true, perfect: true, tspin: true },
    PASSING: 0.16, // a blip (one or two notes) shorter than this may be any note of the key
    cache: {},

    /** A bar's chord tones (its bass, fifth and voicing) and the key's notes over it, as pitch-class flags. */
    tones(bar) {
      if (this.cache[bar.name]) return this.cache[bar.name];
      const [root, voicing] = bar.harm, chord = new Array(12).fill(false), scale = new Array(12).fill(false);
      for (const m of [root, root + 7].concat(voicing)) chord[m % 12] = true;
      for (const pc of [9, 11, 0, 2, 4, 5, 7]) scale[pc] = true;
      // Over the dominant the key borrows its sharps, as the tune does: G# for G, F# for F.
      if (chord[8]) { scale[7] = false; scale[8] = true; }
      if (chord[6]) { scale[5] = false; scale[6] = true; }
      chord.forEach((on, pc) => { if (on) scale[pc] = true; });
      return (this.cache[bar.name] = { chord, scale });
    },

    /** Whether a voice has a pitch to tune: not noise, a click, a low thud, or a low sweep (a thoom, a falling drop). */
    tonal(v) {
      if (!v || v.n || !(v.f > 20 && v.f < 12000)) return false;
      const d = v.d || 0;
      if (d < 0.03) return false;
      if (v.f < 120 && d < 0.15) return false;
      if (v.to > 0 && v.f < 250 && Math.abs(12 * Math.log2(v.to / v.f)) > 4) return false;
      return true;
    },

    /**
     * The note (MIDI) nearest m whose pitch class is in set, within a tritone (on a tie, the lower). With prev and
     * rel (-1, 0, 1), only one that sits that way from prev — the sound's shape — unless none does.
     */
    snap(m, set, prev, rel) {
      let any = null;
      for (let d = 0; d <= 6; d++) {
        for (const c of d ? [m - d, m + d] : [m]) {
          if (!set[((c % 12) + 12) % 12]) continue;
          if (any == null) any = c;
          if (prev == null || Math.sign(c - prev) === rel) return c;
        }
      }
      return any == null ? m : any;
    },

    /** A sound's voices retuned to a timeline's chords, played from context time t0. The list given is left as it was. */
    fit(list, t0, line) {
      if (!list || !line) return list;
      const out = list.map((v) => (v && typeof v === 'object' ? Object.assign({}, v) : v)), notes = [];
      const pitched = out.filter((v) => this.tonal(v)), blip = pitched.length <= 2;
      for (const v of pitched) {
        const m = 69 + 12 * Math.log2(v.f / 440), n = Math.round(m), at = v.at || 0, d = v.d || 0;
        // The chord it will mostly be heard over: a long note struck just before a change belongs to the next one.
        const b = Music.barAt(t0 + at + Math.min(0.15, d * 0.25), line);
        if (!b || !b.bar) return list;
        const t = this.tones(b.bar);
        // A few cents off on purpose (a beating twin) stays that way; a pitch that is nowhere near a note is made one.
        // A run or a chord outlines the chord, however quick its notes; only a blip may pass through the key.
        notes.push({ v, n, frac: Math.abs(m - n) <= 0.08 ? m - n : 0, at, set: blip && d < this.PASSING ? t.scale : t.chord });
      }
      if (!notes.length) return out;
      notes.sort((a, b) => a.at - b.at || a.n - b.n);
      // The move for the whole sound: its first note onto a chord tone, the rest disturbed as little as can be.
      let best = 0, bestCost = Infinity;
      for (let T = -6; T <= 6; T++) {
        if (!notes[0].set[(((notes[0].n + T) % 12) + 12) % 12]) continue;
        let cost = Math.abs(T) * 0.001;
        for (const x of notes) cost += Math.abs(this.snap(x.n + T, x.set) - x.n);
        if (cost < bestCost) { bestCost = cost; best = T; }
      }
      let prev = null;
      for (const x of notes) {
        x.to = prev ? this.snap(x.n + best, x.set, prev.to, Math.sign(x.n - prev.n)) : this.snap(x.n + best, x.set);
        const f = hz(x.to + x.frac), k = f / x.v.f;
        x.v.f = f;
        if (x.v.to > 0) x.v.to *= k;
        prev = x;
      }
      return out;
    },

    /** How long a big sound waits for the next eighth of the music (0 unless it is within QUANTIZE). */
    wait(now, line) {
      const b = Music.barAt(now, line);
      if (!b) return 0;
      const next = b.at + Math.ceil((now - b.at) / b.e - 1e-9) * b.e, d = next - now;
      return d >= 0 && d <= this.QUANTIZE ? d : 0;
    },

    /** What Sound.play plays: the voices (retuned while the music plays) and the delay they go on after. */
    plan(name, list, now, line) {
      line = line || Music.timeline();
      if (!line || !list) return { list, delay: 0 };
      const delay = this.CELEBRATE[name] ? this.wait(now, line) : 0;
      return { list: this.fit(list, now + delay, line), delay };
    },
  };

  // ---- the announcer (Classic) ------------------------------------------------------------------------------------

  /**
   * The announcer calls out the big moments — "single", "double", "triple", "tetris", "T-spin single/double",
   * "back to back", and "amazing" for a perfect clear, "rank up" for a new level, "top out" at the end. The clips are
   * cut from the Tetris Worlds announcer (scripts/splice-voice.py) and embedded, so it sounds the same everywhere.
   */
  const Announcer = {
    enabled: true,
    volume: 0.4,
    buffers: {},
    /**
     * The voice's mixing desk, built once: the raw clips are thinned below 170 Hz, the boxy low-mids and the bright,
     * close-mic top are eased off, a gentle compressor evens the words, and it sits back in the mix at a modest level
     * with sends to the room everything else plays in (the shared reverb) and a soft, filtered stereo echo.
     */
    bus() {
      const ctx = Sound.ctx;
      if (this.input && this.input.context === ctx) return this.input;
      const node = (type, f, q, g) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q != null) b.Q.value = q; if (g != null) b.gain.value = g; return b; };
      const hp = node('highpass', 170, 0.7), mud = node('peaking', 380, 1, -3.5), air = node('highshelf', 5200, null, -6), lp = node('lowpass', 8500, 0.5);
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -26; comp.knee.value = 12; comp.ratio.value = 3; comp.attack.value = 0.006; comp.release.value = 0.18;
      const level = this.level = ctx.createGain(); level.gain.value = this.volume * 0.62;
      this.input = ctx.createGain();
      this.input.connect(hp).connect(mud).connect(air).connect(lp).connect(comp).connect(level);
      level.connect(Sound.master);
      // Room: the same reverb as the sound effects and music, a touch more of it than they use.
      if (Sound.reverb) { const rs = ctx.createGain(); rs.gain.value = 0.32; level.connect(rs).connect(Sound.reverb); }
      // A soft echo either side (not in time with anything), darker on each repeat.
      const echoIn = ctx.createGain(); echoIn.gain.value = 0.16; level.connect(echoIn);
      const merger = ctx.createChannelMerger(2);
      [[0.19, 0], [0.27, 1]].forEach(([t, ch]) => {
        const d = ctx.createDelay(1), fb = ctx.createGain(), f = node('lowpass', 2600, 0.4);
        d.delayTime.value = t; fb.gain.value = 0.24;
        echoIn.connect(d); d.connect(f); f.connect(fb); fb.connect(d); f.connect(merger, 0, ch);
      });
      merger.connect(Sound.master);
      return this.input;
    },
    setVolume(v) { if (v === this.volume) return; this.volume = v; if (this.level) this.level.gain.value = v * 0.62; },
    decode(key) {
      const ctx = Sound.ensure();
      const b64 = (L.VOICE_CLIPS || {})[key];
      if (!ctx || !b64) return Promise.resolve(null);
      if (!this.buffers[key]) {
        const bin = root.atob(b64), bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        this.buffers[key] = new Promise((res) => {
          try { const p = ctx.decodeAudioData(bytes.buffer, res, () => res(null)); if (p && p.catch) p.catch(() => res(null)); } catch (e) { res(null); }
        });
      }
      return this.buffers[key];
    },
    /** Says a list of clip keys in order, with a breath between them. Cuts off anything still being said. */
    say(keys) {
      if (!this.enabled || !keys || !keys.length) return false;
      const ctx = Sound.ensure();
      if (!ctx) return false;
      if (ctx.state === 'suspended') ctx.resume();
      const token = this.token = (this.token || 0) + 1;
      if (this.out) { try { this.out.gain.setTargetAtTime(0, ctx.currentTime, 0.03); } catch (e) { /* gone */ } }
      const out = this.out = ctx.createGain();
      out.connect(this.bus());
      Promise.all(keys.map((k) => this.decode(k))).then((bufs) => {
        if (token !== this.token) return;
        const start = ctx.currentTime + 0.02;
        let at = start;
        for (const buf of bufs) {
          if (!buf) continue;
          const src = ctx.createBufferSource();
          src.buffer = buf; src.connect(out); src.start(at);
          at += buf.duration + 0.06;
        }
        Music.duck(start, at);
      });
      this.last = keys.join(' ');
      return true;
    },
    /** The clips for a lock result (and a level-up), or null. A T-spin single or double is one clip; a triple (and
     * a Mini, which has no clip of its own) is "T-spin" and the line count. */
    phrase(r, levelUp) {
      const names = ['', 'single', 'double', 'triple', 'tetris'];
      let k = [];
      if (r.tspin || r.mini) {
        const n = Math.min(r.lines, r.mini ? 2 : 3);
        k = n === 1 || n === 2 ? ['tspin_' + names[n]] : n ? ['tspin', names[n]] : ['tspin'];
      } else if (r.lines) k = [names[Math.min(r.lines, 4)]];
      if (k.length && r.b2b) k.unshift('b2b');
      if (r.perfect) k.push('perfect');
      if (levelUp) k.push('levelup');
      return k.length ? k : null;
    },
  };

  L.Sound = Sound;
  L.Music = Music;
  L.SONG = SONG;
  L.Harmony = Harmony;
  L.Announcer = Announcer;
})(typeof globalThis !== 'undefined' ? globalThis : this);
